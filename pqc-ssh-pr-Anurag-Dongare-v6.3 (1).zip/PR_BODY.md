## What
Adds `docs/pqc-ssh/` with server/client configs (fallback + sntrup + mlkem), automation (`setup-pqc-ssh.ps1`, `auto-pqc-proof.ps1`), and smoke tests.

## Why
Windows 9.5p2 lacks PQ KEX. Docs/automation provide safe fallback today and auto-upgrade once PQ is present.

## Automated Proof
Run locally or see attached Issue for proof log.
