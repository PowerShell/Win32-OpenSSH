### Problem
Windows OpenSSH builds (e.g., 9.5p2) lack post-quantum (PQ) key exchanges, while endpoints (e.g., GitHub) now advertise them. Users get silent fallback without clarity.

### Proposal
Add `docs/pqc-ssh/` with fallback + PQ configs, automation (`setup-pqc-ssh.ps1`, `auto-pqc-proof.ps1`), and smoke tests.

### Why
Zero code risk; immediate clarity; forward compatible with NIST FIPS 203/204 and OpenSSH PQ defaults.

### Automated Proof Log
(pasted by automation if proof-log.txt is present)
